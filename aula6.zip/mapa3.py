import folium
from sklearn.cluster import KMeans
from geopy import distance

coordenada1 = [-22.9064, -47.0616]
coordenada2 = [-22.9064+0.01, -47.0616+0.01]

mapa = folium.Map(location=coordenada1, zoom_start=13)
# linha
line = folium.PolyLine(locations=[coordenada1, coordenada2], color='blue')
# Adiciona a linha ao mapa
line.add_to(mapa)

# Cria um marcador
folium.Marker(coordenada1, popup=f' Campinas').add_to(mapa)
mapa.save("Mapa_linha.html")
print("fim!")

# Tarefa: Crie um triângulo (3 linhas) ligando as cidades de Campinas,
# Piracicaba e Limeira. Coloque um marcador em cada cidade,
# contendo o nome da cidade.
