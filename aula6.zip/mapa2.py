import folium

lat = -22.9064
long = -47.0616

mapa = folium.Map(location=[lat, long], zoom_start=15)

# O código abaixo cria um círculo ao redor da coordenada
# 1) aumente o raio para 500, coloque opacidade 0.2 e cor
# vermelha
# 2) Mude o centro do mapa para a FT unicamp.
raio = 30
folium.Circle(radius=raio, location=[lat, long], color='black', fill=True,
              fill_opacity=1).add_to(mapa)

mapa.save("Mapa_circulo.html")

print("fim!")


